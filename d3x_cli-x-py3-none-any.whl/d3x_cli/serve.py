import click
import requests
import json
import os
import shutil
from tabulate import tabulate
from pathlib import Path
from d3x_cli.utils import  get_formatted_name,output_convertion
userdata_dir = (
    "/userdata" if "D3X_NAMESPACE" in os.environ else str(Path.home())
)
ini_file = f"{userdata_dir}/.d3x.ini"


class Struct:
    def __init__(self, **entries):
        self.__dict__.update(entries)


def url_prefix(context):
    if context.auth_type == "cookie":
        prefix = "llms"
    else:
        # TODO: can we change the name to 'serve' instead of 'llm'
        prefix = "llm"
    return prefix


CLI_CTX_OBJ = None


@click.group()
@click.pass_obj
def serve(obj):
    """Group for ray commands."""
    global CLI_CTX_OBJ
    CLI_CTX_OBJ = obj


@serve.command()
@click.pass_obj
@click.option("-n", "--name", required=True, help="name of the ray serve")
@click.option(
    "-r",
    "--registry_type",
    required=True,
    type=click.Choice(["hugging_face", "mlflow", "local", "none"]),
    help="registry type",
)
@click.option("--hface_repoid", help="hugging face repo id")
@click.option("--hface_tokenizer", help="hugging face tokenizer")
@click.option("--hface_classifier", help="hugging face classifier")
@click.option("--hface_token", help="hugging face token")
@click.option("--model", help="mlflow model name")
@click.option("--model_version", help="mlflow model version")
# @click.option("--model_uri", help="mlflow model URI")
# @click.option("--git_repo", help="user git repo")
# @click.option("--git_is_private", help="is it private repo")
# @click.option("--git_apikey", help="user git repo")
@click.option("--depfilepath", help="deployment filepath")
@click.option("--working_dir", help="local serving directory path")
@click.option("--is_private_repo", is_flag=True, help="private repo")
@click.option("--repo_name", help="github repo name")
@click.option("--repo_org", help="github personal/organization account")
@click.option("--access_token", help="github access token")
@click.option("--branch_name", help="github branch name")
@click.option("--commit_id", help="github commit id")
@click.option("--unprotected", is_flag=True, help="serving without token")
@click.option("-e", "--env", help="environment variable")


# @click.option("--deployment_reqfilepath", help="ray serve dependency package filepath")
@click.option("--ngpus", default="0", help="number of gpus")
@click.option("--min_cpu", default="2", help="min number of cpus for cluster creation")
@click.option("--max_cpu", default="", help="max number of cpus per cluster creation")
@click.option(
    "--min_memory", default="3", help="min memory for cluster cluster creation"
)
@click.option(
    "--max_memory", default="", help="max memory for cluster cluster creation"
)
@click.option("--min_replicas", default="1", help="min deployment replicas")
@click.option("--max_replicas", default="2", help="max deployment replicas")
@click.option("--max_concurrent_requests", default="3", help="max concurrent requests")
@click.option("--description", help="deployment description")
@click.option("--image", help="cluster image")
@click.option("--publish", is_flag=True, help="publish the  deployment")
@click.option("--no_rsrc_limits", is_flag=True, help="no resource limits")
@click.option("--type", help="node selector")
@click.option("--timeout", default=3600, help="deployment timeout")
@click.option("--kserve", is_flag=True, help="enable kserve deployment")
@click.option(
    "--model_format",
    type=click.Choice(
        [
            "tensorflow",
            "sklearn",
            "pytorch",
            "xgboost",
            "pmml",
            "lightgbm",
            "paddle",
            "mlflow",
            "custom",
        ]
    ),
    help="model format in case of kserve deployment",
)
@click.option("--model_path", help="local path of model for kserve deployment")
@click.option(
    "--protocol_version",
    type=click.Choice(["v1", "v2"]),
    default="v1",
    help="dataplane protocol",
)
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
def create(
    obj,
    name,
    registry_type,
    hface_repoid,
    hface_tokenizer,
    hface_classifier,
    hface_token,
    # model_uri,
    model,
    model_version,
    # git_repo,
    is_private_repo,
    unprotected,
    repo_name,
    repo_org,
    access_token,
    branch_name,
    commit_id,
    depfilepath,
    working_dir,
    ngpus,
    min_cpu,
    max_cpu,
    min_memory,
    max_memory,
    min_replicas,
    max_replicas,
    max_concurrent_requests,
    description,
    image,
    no_rsrc_limits,
    type,
    env,
    publish,
    timeout,
    kserve,
    model_format,
    model_path,
    protocol_version,output
):
    username = repo_org
    git_repo = ""
    serving_token = ""
    if kserve:
        if not model_format:
            print("please provide model format for kserve deployment")
            return
        if model_format != "custom":
            if registry_type == "local" and not model_path:
                print("please provide model path for kserve deployment")
                return
            if registry_type == "mlflow" and (not model or not model_version):
                print("please provide model and model_version for mlflow registry")
                return
        if model_format == "custom" and not image:
            print("please provide image for custom kserve deployment")
            return
    else:
        """Create Ray Serve"""
        # print (f"deployment timeout: {timeout}")
        if registry_type == "local":
            print("ray doesn't have support for local.")
            return
        if not username and repo_name:
            print("please provide github personal/organisation account in the options")
            return
        if not repo_name and username:
            print("please provide github repo name in the options")
            return

        if is_private_repo:
            if not access_token:
                print("please provide access token for the repo")
                return

        def repo(cwd):
            cwd_path = Path(cwd)
            shutil.make_archive(
                cwd_path.as_posix(), "zip", cwd_path.parent.as_posix(), cwd_path.name
            )
            return f"file://{cwd}"

        if working_dir:
            cwd = working_dir
            git_repo = repo(cwd)
        elif repo_name and username:
            if branch_name:
                git_repo = f"https://github.com/{username}/{repo_name}/archive/refs/heads/{branch_name}.zip"
            elif commit_id:
                git_repo = (
                    f"https://github.com/{username}/{repo_name}/archive/{commit_id}.zip"
                )
            else:
                git_repo = f"https://github.com/{username}/{repo_name}/archive/refs/heads/master.zip"
        elif (not username) and (not repo_name):
            cwd = os.getcwd()
            git_repo = repo(cwd)

        if not unprotected:
            serving_token = os.environ.get("SERVE_KEY", "")
            if env:
                (key, value) = env.split("=")
                if key == "SERVE_KEY":
                    serving_token = value

    ##TODO: do we need to move the validation & data formatting inside api ?
    data = {
        "name": name,
        "registry_type": registry_type,
        "hface_repoid": hface_repoid,
        "hface_tokenizer": hface_tokenizer,
        "hface_classifier": hface_classifier,
        "hface_token": hface_token,
        "model": model,
        "model_version": model_version,
        # "model_uri": model_uri,
        # "cluster_type": "ray_serve",
        # "git_is_private": False
        # ngpus: 0
        "unprotected": unprotected,
        "serving_token": serving_token,
        "git_is_private": is_private_repo,
        "git_repo": git_repo,
        "git_username": username,
        "git_apikey": access_token,
        "deployment_filepath": depfilepath,
        "ngpus": ngpus,
        "min_cpu": min_cpu,
        "max_cpu": max_cpu,
        "min_memory": min_memory,
        "max_memory": max_memory,
        "min_replicas": min_replicas,
        "max_replicas": max_replicas,
        "max_concurrent_requests": max_concurrent_requests,
        "description": description,
        "timeout": timeout,
        "image": image,
        "node_selector": type,
        "no_resource_limit": no_rsrc_limits,
        "publish": publish,
        "kserve": kserve,
        "model_format": model_format,
        "model_path": model_path,
        "protocol_version": protocol_version,
    }
    prefix = url_prefix(obj)
    r = requests.post(
        f"{obj.url}/{prefix}/api/deployments/",
        json=data,
        headers=obj.headers,
        verify=False,
    )
    if output is None:
        print(r.json())
    else:
        output_convertion(r.json(), output)


@serve.command()
@click.pass_obj
@click.argument("name")
@click.option("-u", "--user", required=False, default=None, help="deployment owner name")
@click.option("-p", "--published", required=False, is_flag=True, type=bool, help="published userapp")
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
def get(obj, name, user, output, published = False):
    """Get Deployment"""
    if user != None and published:
        click.echo("--user is not supported with --published")
        raise click.Abort()
    prefix = url_prefix(obj)
    params = {}
    if user != None:
        params={"namespace": user}
    if published:
        params={"namespace": "published"}
    r = requests.get(
        f"{obj.url}/{prefix}/api/deployments/{name}", headers=obj.headers, params=params, verify=False
    )
    resp = r.json()
    if r.status_code == 200:
        resp["deployment"]["endpoint"] = (
            f"{obj.url}{resp['deployment']['endpoint']}"
            if resp["deployment"]["endpoint"]
            else ""
        )
        if output is None:
            print(resp)
        else:
            output_convertion(resp, output)
    else:
        print(resp)


@serve.command()
@click.pass_obj
@click.argument("id")
def status(obj, id):
    """Deployment Status"""
    ##TODO: print in table format
    prefix = url_prefix(obj)
    r = requests.get(
        f"{obj.url}/{prefix}/api/deployments/published/{id}",
        headers=obj.headers,
        verify=False,
    )
    if r.status_code == 200:
        resp = r.json()
        print(json.dumps(resp, indent=4))
    else:
        print(r.text)


@serve.command()
@click.pass_obj
@click.option("-a", "--all", is_flag=True, default= None,  help="List all the deployments")
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
def list(obj, all,output):
    """List Deployments"""
    ## TODO: Make sure cluster type is coming as either
    ## ray_serve or k_serve
    prefix = url_prefix(obj)
    params = {}
    if all != None:
        params={"namespace": "*"}
    r = requests.get(
        f"{obj.url}/{prefix}/api/deployments/", headers=obj.headers, params=params, verify=False
    )
    if r.status_code != 200:
        click.echo(r.text)
        raise click.Abort()

    clusters = [["id", "name",  "user", "published", "type", "endpoint", "serving_token", "status"]]
    for cluster in r.json():
        c = Struct(**cluster)
        endpoint_prefix = f"{obj.url}" if (c.cluster_type == "ray_serve") else ""
        clusters.append(
            [
                c.id,
                c.name,
                c.username,
                c.publish if c.cluster_type != "sky_serve" else False,
                c.cluster_type,
                f"{endpoint_prefix}{c.endpoint}" if (c.endpoint) else "",
                c.serving_token,
                c.status,
            ]
        )
    if output is None:
        print(tabulate(clusters, headers="firstrow", tablefmt="presto"))
    else:
        output_convertion(clusters, output)
@serve.command()
@click.pass_obj
@click.argument("name")
@click.option("-u", "--user", required=False, default=None, help="deployment owner name")
@click.option("-p", "--published", required=False, is_flag=True, type=bool, help="published userapp")
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
def delete(obj, name, user, output, published=False):
    """Delete Deployment"""
    if user != None and published:
        click.echo("--user is not supported with --published")
        raise click.Abort()
    prefix = url_prefix(obj)
    params = {}
    if user != None:
        params={"namespace": user}
    if published:
        params={"namespace": "published"}
    r = requests.delete(
        f"{obj.url}/{prefix}/api/deployments/{name}", headers=obj.headers, params=params, verify=False
    )
    if output is None:
        print(r.text)
    else:
        output_convertion(r.text, output)
