import click
import requests
import json
import os
import re
import shutil
from tabulate import tabulate
from pathlib import Path
from d3x_cli.utils import  get_formatted_name,output_convertion, get_dkubex_apikey
userdata_dir = (
    "/userdata" if "D3X_NAMESPACE" in os.environ else str(Path.home())
)
ini_file = f"{userdata_dir}/.d3x.ini"

from websockets.sync.client import connect
from websockets.exceptions import ConnectionClosedError

class Struct:
    def __init__(self, **entries):
        self.__dict__.update(entries)


def url_prefix(context):
    if context.auth_type == "cookie":
        prefix = "llms"
    else:
        # TODO: can we change the name to 'serve' instead of 'llm'
        prefix = "llm"
    return prefix


CLI_CTX_OBJ = None


@click.group()
@click.pass_obj
def llms(obj):
    """Group for llms commands."""
    global CLI_CTX_OBJ
    CLI_CTX_OBJ = obj


@llms.command()
@click.pass_obj
@click.option("-n", "--name", required=True, help="name of the deployment")
@click.option(
    "-m",
    "--model",
    required=False,
    help="name or path of the model to deploy for serving",
)
@click.option("--base_model", required=False, help="base model name")
@click.option("--token", help="hugging face token")
@click.option("--config", help="github raw content url or local config path")
@click.option(
    "--mlflow",
    help="name of the mlflow registered model along with version (example: diffusion:1)",
)
@click.option("--image", required=False, help="customized docker image for llm deployment")
@click.option("--type", help="instance type")
@click.option("--min_replicas", default="0", help="minimum replicas")
@click.option("--max_replicas", default="2", help="maximum replicas")
@click.option("--publish", is_flag=True, help="publish the deployment")
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
@click.option('-sky', '--remote-sky', "skyjob", required=False, default=False, is_flag=True, help="If the model should be deployed on remote sky cluster.")
@click.option("--sky-accelerator", "accelerator", default="A10G:1", help="accelerator for remote sky cluster")
@click.option("--sky-yaml", "sky_yaml", required=False, default=None, help="Path to custom yaml file for sky serve.")
@click.option('--use-spot', "use_spot", required=False, default=False, is_flag=True, help="Whether to request spot instances for sky deployments.")

def deploy(
    obj,
    name,
    model,
    base_model,
    token,
    config,
    mlflow,
    image,
    type,
    min_replicas,
    max_replicas,
    publish,
    output,
    skyjob,
    accelerator,
    sky_yaml,
    use_spot,
):
    """Deploy a llm on dkubex."""

    if use_spot and (not skyjob):
        print("--use-spot option is only supported for sky deployments.")
        return

    if skyjob and (not model) and (not config):
        print("Please provide a model (--model) or config file (--config) for deploying on remote sky cluster")
        return

    dkubex_apikey = None
    if (skyjob): #assert dkubex_apikey, "For sky jobs, -k/--dkubex-apikey must be passed."
        dkubex_apikey = get_dkubex_apikey(obj)

    if not model and not config and not mlflow:
        print("please provide either model, config ")
        return

    # TODO: mlflow only if model provided is path ...?

    prefix = url_prefix(obj)
    resp = requests.get(
        f"{obj.url}/{prefix}/api/llms/", headers=obj.headers, verify=False
    )

    llmsdb = resp.json()["llms"]
    if config:
        file_path = os.path.abspath(config)
        if Path(file_path).exists():
            config = file_path

    # if Path(model).exists():

    if model and not Path(model).exists():
        for entry in llmsdb:
            if entry["model_id"] == model:
                model = entry["name"]
                if entry.get("needs_token", False) == True and (not token):
                    token = input(
                        "This model requires huggingface token, please input : "
                    )
                break
        else:
            print("please provide valid registered model")
            return
    data = {
        "depname": name,
        "llm": {
            "name": model,
            "token": token,
            "config": config,
            "image": image,
            "base_model": base_model,
            "instance_type": type,
            "publish": publish,
            "min_replicas": min_replicas,
            "max_replicas": max_replicas,
            "mlflow": mlflow,
        },
        "sky": {
            "skyjob": skyjob,
            "accelerator": accelerator,
            "sky_yaml": sky_yaml,
            "use_spot": use_spot,
        },
        "dkubex_apikey": dkubex_apikey,
    }
    prefix = url_prefix(obj)

    post_url = f"{obj.url}/{prefix}/api/llms/deploy"
    if (skyjob) :
        post_url =  f"{obj.url}/{prefix}/api/llms/deploy/sky"

    r = requests.post(
        post_url,
        json=data,
        headers=obj.headers,
        verify=False,
        timeout=360,
    )

    if r.status_code != 200:
        if skyjob:
            # if r.status_code == 504:
            #     print(f"Deployment initialted. Check the status using the following command:\nd3x sky serve status {name}")
            #     return
            print(f"Failed to deploy model. Status code: {r.status_code}")
        else:
            print(f"Error: Failed to deploy model. Status code: {r.status_code}")
        return

    if skyjob:
        url = r.json()['url']
        sky_args = r.json()['sky_args']
        with connect(f"{url}/sky/{sky_args[0]}", additional_headers= r.json()['auth'], open_timeout=100, close_timeout=100) as websocket:
            data = r.json()['data']
            # print(f"sky controller data >>>>> {json.dumps(data)}", flush=True)
            websocket.send(json.dumps(data))
            try:
                for msg in websocket:
                    print(msg, end="", flush=True)
            except ConnectionClosedError:
                print(f"Timed out waiting serve cluster creation.\nUse the following command to check the status: \n d3x sky serve status {r.json()['depname']}")
        return
    if output is None:
        print(r.json())
    else:
        output_convertion(r.json(), output)

    return


# @llms.command()
# @click.pass_obj
# @click.option("-n", "--name", required=True, help="name of the model for registration")
# @click.option(
#    "-f", "--file", required=True, help="raw github url of model definition in yaml"
# )
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)

def register(obj, name, file,output):
    """Register a model with dkubex"""
    # MAK - TODO
    pattern = r"https://raw\.githubusercontent\.com/[^/]+/[^/]+/[^/]+/[^/]+/.+"
    if not re.match(pattern, file):
        print("please provide valid raw github url")
        return
    prefix = url_prefix(obj)
    data = {"name": name, "file": file}
    resp = requests.post(
        f"{obj.url}/{prefix}/api/llms/register",
        json=data,
        headers=obj.headers,
        verify=False,
    )
    if output is None:
        print(resp.json())
    else:
        output_convertion(resp.json(), output)
        
    return


@llms.command()
@click.pass_obj
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)

def list(obj,output):
    """List the supported llms"""
    
    prefix = url_prefix(obj)
    
    resp = requests.get(
        f"{obj.url}/{prefix}/api/llms/", headers=obj.headers, verify=False
    )
    llmsdb = resp.json()["llms"]
    llmsdb = sorted(llmsdb, key=lambda x: x["name"])

    from rich.console import Console
    from rich.table import Table
    import yaml
    import json

    console = Console()

    table = Table(
        show_header=True,
        header_style="bold magenta",
        title="LLM models supported on DKubeX.",
        show_lines=True,
    )
    table.add_column("LLM Name")
    table.add_column("Accelerator")
    table.add_column("DeploymentConfig", justify="left")
    table_output = [["LLM Name", "Accelerator", "DeploymentConfig"]]
    for entry in llmsdb:
        name = entry["model_id"]
        accelerator = entry["accelerator"]
        table.add_row(name, entry["accelerator"], entry["config"])
        table_output.append([name, entry["accelerator"], entry["config"]])
    if output is None:
        console.print(table)
    else:
        output_convertion(table_output, output)
