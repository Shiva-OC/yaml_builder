import click
import requests
from d3x_cli.utils import  get_formatted_name,output_convertion
@click.group()
@click.pass_context
def apikey(ctx):
    """Group for apikey commands."""
    pass

@apikey.command()
@click.pass_obj
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
def get(obj,output):
    """Get user apikey"""
    r = requests.get(f"{obj.url}/api/{obj.api_prefix}/apikey/", headers=obj.headers, verify=False)
    if r.status_code != 200:
        click.echo(r.text)
        raise click.Abort()
    if output is None:
        print(r.json())
    else:
        output_convertion(r.json(), output)
        
    # print(r.json())
    
@apikey.command()
@click.pass_obj
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
def generate(obj,output):
    """Generate user apikey"""
    r = requests.post(f"{obj.url}/api/{obj.api_prefix}/apikey/", headers=obj.headers, verify=False)
    if r.status_code != 200:
        click.echo(r.text)
        raise click.Abort()
    if output is None:
        print(r.json())
    else:
        output_convertion(r.json(), output)