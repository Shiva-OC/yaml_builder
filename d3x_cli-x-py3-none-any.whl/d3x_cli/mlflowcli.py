import click
import requests
from tabulate import tabulate
import joblib
import os
import os.path as path
import importlib.util
from d3x_cli.utils import  output_convertion

import sys
import os.path as path

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"
mlfc = None


@click.group()
@click.pass_obj
def mlflow(obj):
    """Group for mlflow commands."""
    global CLI_CTX_OBJ
    CLI_CTX_OBJ = obj


@click.group()
@click.pass_obj
def experiments(obj):
    """mlflow experiments."""
    pass




@click.group()
@click.pass_obj
def models(obj):
    """List & Manage mlflow models registry"""
    r = requests.get(f"{obj.url}/api/{obj.api_prefix}/apikey/", headers=obj.headers, verify=False)
    if r.status_code != 200:
        click.echo(r.text)
        raise click.Abort()
    api_key=r.json()
    os.environ["MLFLOW_TRACKING_TOKEN"] = api_key
    os.environ["MLFLOW_TRACKING_INSECURE_TLS"] = "true"
    os.environ["MLFLOW_TRACKING_URI"] =  f"{obj.url}/api/mlflow"
    import mlflow
    import logging

    logging.getLogger("mlflow").setLevel(logging.ERROR)

    global mlfc
    mlfc = mlflow.MlflowClient()


@experiments.command()
@click.pass_obj
@click.argument("id")
def delete(obj, id):
    """Delete Experiment"""
    click.echo(f"please wait while deleting the experiment: {id}")
    resp = requests.delete(
        f"{obj.url}/api/{obj.api_prefix}/mlflow/experiments/{id}/delete",
        headers=obj.headers,
        verify=False,
    )
    if resp.status_code != 200:
        click.echo(resp.text)
        raise click.Abort()
    click.echo(resp.json())


@experiments.command()
@click.pass_obj
@click.argument("id")
def archive(obj, id):
    """Archive Experiment"""
    click.echo(f"please wait while archiving the experiment: {id}")
    resp = requests.post(
        f"{obj.url}/api/{obj.api_prefix}/mlflow/experiments/{id}/archive",
        headers=obj.headers,
        verify=False,
    )
    if resp.status_code != 200:
        click.echo(resp.text)
        raise click.Abort()
    click.echo(resp.json())


@experiments.command()
@click.pass_obj
def list(obj):
    """List Experiments"""
    resp = requests.get(
        f"{obj.url}/api/{obj.api_prefix}/mlflow/experiments",
        headers=obj.headers,
        verify=False,
    )
    if resp.status_code != 200:
        click.echo(resp.text)
        raise click.Abort()
    results = resp.json()
    exps = [["experiments_id", "name", "artifact_location", "life_cycle_stage", "tags"]]

    for val in results:
        exps.append(
            [
                val["_experiment_id"],
                val["_name"],
                val["_artifact_location"],
                val["_lifecycle_stage"],
                val["_tags"],
            ]
        )
    print(tabulate(exps, headers="firstrow", tablefmt="presto"))


@experiments.command()
@click.pass_obj
@click.argument("id")
def restore(obj, id):
    """Restore Experiment"""
    click.echo(f"please wait while restoring the experiment: {id}")
    resp = requests.post(
        f"{obj.url}/api/{obj.api_prefix}/mlflow/experiments/{id}/restore",
        headers=obj.headers,
        verify=False,
    )
    if resp.status_code != 200:
        click.echo(resp.text)
        raise click.Abort()
    click.echo(resp.json())


@models.command()
@click.pass_obj
@click.argument("name")
@click.argument("version")
def delete(obj, name, version):
    """Delete Model"""
    click.echo(f"please wait while deleting the model: {name}, version: {version}")
    resp = requests.delete(
        f"{obj.url}/api/{obj.api_prefix}/mlflow/models/{name}/{version}",
        headers=obj.headers,
        verify=False,
    )
    if resp.status_code != 200:
        click.echo(resp.text)
        raise click.Abort()
    click.echo(resp.json())

@models.command("import")
@click.argument("name")
@click.argument(
    "model_type",
    type=click.Choice(["pytorch", "tensorflow", "sklearn", "xgboost", "custom_model"]),
)
@click.argument("saved_model_path")
@click.option("--class_path", help="pytorch class file path")
@click.option("--class_instance", help="class instance")
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)

def impt(name, model_type, saved_model_path, class_path, class_instance,output):
    """Import saved model to mlflow"""
    import mlflow.pyfunc

    class TrainedModel(mlflow.pyfunc.PythonModel):
        def __init__(self, model):
            self.model = model

        def predict(self, context, model_input):
            return {}

    try:
        abs_path = lambda x: os.path.abspath(x)
        saved_model_path = abs_path(saved_model_path)
        if model_type == "tensorflow":
            import mlflow.tensorflow
            import tensorflow as tf

            loaded_model = tf.keras.models.load_model(saved_model_path)

            # Start an MLflow run
            with mlflow.start_run():
                # Log the TensorFlow model to MLflow
                mlflow.tensorflow.log_model(
                    model=loaded_model,
                    artifact_path=f"{model_type}-{name}",
                    registered_model_name=name,
                )
        if model_type == "sklearn":
            import mlflow.sklearn
            # Load the model from the saved file
            model = joblib.load(saved_model_path)

            # Start an MLflow run
            with mlflow.start_run():
                mlflow.sklearn.log_model(
                    model,
                    artifact_path=f"{model_type}-{name}",
                    registered_model_name=name,
                )
        if model_type == "pytorch":
            import mlflow.pytorch
            absolute_path_to_class = abs_path(class_path)
            class_name = class_instance  # "model"
            model_path = saved_model_path

            class_directory = path.dirname(absolute_path_to_class)
            sys.path.append(class_directory)

            # Get module name
            module_name = os.path.basename(absolute_path_to_class)

            # Load the module dynamically
            spec = importlib.util.spec_from_file_location(
                module_name, absolute_path_to_class
            )
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            # Get the class instance from the module
            loaded_model = getattr(module, class_name)

            import torch

            # Load the saved model parameters
            loaded_model.load_state_dict(torch.load(model_path))
            loaded_model.eval()  # Set the model to evaluation mode

            # Start an MLflow run
            with mlflow.start_run():
                mlflow.pytorch.log_model(
                    loaded_model,
                    artifact_path=f"{model_type}-{name}",
                    registered_model_name=name,
                )
        if model_type == "xgboost":
            import mlflow.xgboost
            import xgboost as xgb

            loaded_model = xgb.Booster()
            loaded_model.load_model(saved_model_path)

            # Start an MLflow run
            with mlflow.start_run():
                mlflow.xgboost.log_model(
                    loaded_model,
                    artifact_path=f"{model_type}-{name}",
                    registered_model_name=name,
                )
        if model_type == "custom_model":
            with mlflow.start_run():
                mlflow.log_artifacts(saved_model_path, artifact_path=f"{name}")
                tmodel = TrainedModel("cust_model")
                mlflow.pyfunc.log_model(
                    f"{name}",
                    python_model=tmodel,
                    artifacts={
                        f"{name}": mlflow.get_artifact_uri(artifact_path=f"{name}")
                    },
                    registered_model_name=f"{name}",
                )
        if output is None:
            click.echo(f"Model {name} imported successfully.")
        else:
            click.echo(output_convertion(f"Model {name} imported successfully.", output))
    except Exception as e:
            click.echo(f"Failed to import the model: {name} \n\nError: {e}")
@models.command()
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
def list(output):
    """List models registered in mlflow registry"""
    filter_string = None
    results = mlfc.search_registered_models(filter_string=filter_string)
    models = [["name", "latest_version", "runid", "status"]]

    for res in results:
        for mv in res.latest_versions:
            models.append([mv.name, mv.version, mv.run_id, mv.status])

    if output is None:
        print(tabulate(models, headers="firstrow", tablefmt="presto"))
    else:
        output_convertion(models, output)


mlflow.add_command(experiments)
mlflow.add_command(models)
